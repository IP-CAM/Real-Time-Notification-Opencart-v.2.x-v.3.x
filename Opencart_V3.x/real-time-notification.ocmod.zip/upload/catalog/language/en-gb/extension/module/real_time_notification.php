<?php
// Heading
$_['heading_title'] = 'Real Time Notification';
$_['text_sale_notification'] = '{{firstname}} from {{city}} just bought {{product}}';
$_['text_product_name'] = '<a href="%s" target="_blank">%s</a>';
